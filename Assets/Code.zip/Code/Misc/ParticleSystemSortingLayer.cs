﻿using UnityEngine;
using System.Collections;

#if UNITY_EDITOR
using UnityEditor;

[ExecuteInEditMode]
#endif

public class ParticleSystemSortingLayer : MonoBehaviour 
{
	public bool addchilds;
}
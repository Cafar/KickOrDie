﻿using UnityEngine;
using System.Collections;

public static class Achievements 
{

	public static string GEMELOS 				= "CgkI9f6Vjf0LEAIQAw";

	public static string MITSU				 	= "CgkI9f6Vjf0LEAIQBA";

	public static string PIERNA_RAPIDA		 	= "CgkI9f6Vjf0LEAIQBQ";

	public static string TROTA				 	= "CgkI9f6Vjf0LEAIQBg";

	public static string INTOCABLE			 	= "CgkI9f6Vjf0LEAIQBw";

	public static string COMIENZO			 	= "CgkI9f6Vjf0LEAIQCA";

	public static string MAESTRO			 	= "CgkI9f6Vjf0LEAIQCQ";

	public static string GENIN				 	= "CgkI9f6Vjf0LEAIQCg";

	public static string CHUNIN				 	= "CgkI9f6Vjf0LEAIQCw";

	public static string JONIN				 	= "CgkI9f6Vjf0LEAIQDA";

	public static string KAGE				 	= "CgkI9f6Vjf0LEAIQDQ";

	public static string GRACIAS			 	= "CgkI9f6Vjf0LEAIQDg";

	public static string FACEBOOK			 	= "CgkI9f6Vjf0LEAIQDw";

	public static string NOPUBLI			 	= "CgkI9f6Vjf0LEAIQEA";

	

	public static string RANKING				= "CgkI9f6Vjf0LEAIQAg";

}
